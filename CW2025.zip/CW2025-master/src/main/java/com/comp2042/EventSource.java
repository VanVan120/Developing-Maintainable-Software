package com.comp2042;

public enum EventSource {
    USER, THREAD
}
