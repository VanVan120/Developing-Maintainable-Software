package com.comp2042.logic.bricks;

public interface BrickGenerator {

    Brick getBrick();

    Brick getNextBrick();
}
