package com.comp2042;

public enum EventType {
    DOWN, LEFT, RIGHT, ROTATE
}
